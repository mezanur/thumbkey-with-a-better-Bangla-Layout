@file:Suppress("ktlint:standard:no-wildcard-imports")

package com.dessalines.thumbkey.keyboards

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import com.dessalines.thumbkey.utils.*
import com.dessalines.thumbkey.utils.ColorVariant.*
import com.dessalines.thumbkey.utils.FontSizeVariant.*
import com.dessalines.thumbkey.utils.KeyAction.*
import com.dessalines.thumbkey.utils.SwipeNWay.*

// Frequency-based 3x3 Bengali layout.
//
//   ক  ে  ত
//   ন  া  র
//   ব  ি  ্
//
// The 9 most frequent symbols (া ্ র ে ি ন ক ত ব) are center taps, so they never need a swipe.
// Related letters share a key: vowel + kar forms, and consonants grouped by sound.
// Swipe directions: topLeft(↖) top(↑) topRight(↗) left(←) right(→) bottomLeft(↙) bottom(↓) bottomRight(↘)
//
// The "shifted" slot is repurposed as a punctuation/symbol layer (Bengali has no case).
val KB_BN_THUMBKEY_MAIN =
    KeyboardC(
        listOf(
            // ---------------- Row 1: ক  ে  ত ----------------
            listOf(
                KeyItemC(
                    center = KeyC("\u0995", size = LARGE), // ক ka  (velars)
                    top = KeyC("\u0996"), // খ kha
                    left = KeyC("\u0997"), // গ ga
                    right = KeyC("\u0998"), // ঘ gha
                    bottom = KeyC("\u0999"), // ঙ nga
                    bottomRight = KeyC("\u0995\u09CD\u09B7"), // ক্ষ ksha
                    topLeft = KeyC("\u0964", color = MUTED), // । dari
                    topRight = KeyC(",", color = MUTED),
                    bottomLeft = KeyC("?", color = MUTED),
                ),
                KeyItemC(
                    center = KeyC("\u09C7", size = LARGE), // ে e-kar  (e/o vowels)
                    top = KeyC("\u098F"), // এ e
                    left = KeyC("\u09C8"), // ৈ oi-kar
                    topLeft = KeyC("\u0990"), // ঐ ai
                    bottom = KeyC("\u09CB"), // ো o-kar
                    bottomRight = KeyC("\u0993"), // ও o
                    bottomLeft = KeyC("\u09CC"), // ৌ ou-kar
                    topRight = KeyC("\u0994"), // ঔ au
                ),
                KeyItemC(
                    center = KeyC("\u09A4", size = LARGE), // ত ta  (dentals + retroflexes)
                    top = KeyC("\u09A5"), // থ tha
                    left = KeyC("\u09A6"), // দ da
                    right = KeyC("\u09A7"), // ধ dha
                    bottom = KeyC("\u09CE"), // ৎ khanda ta
                    topLeft = KeyC("\u099F"), // ট Ta
                    topRight = KeyC("\u09A0"), // ঠ Tha
                    bottomLeft = KeyC("\u09A1"), // ড Da
                    bottomRight = KeyC("\u09A2"), // ঢ Dha
                ),
                EMOJI_KEY_ITEM,
            ),
            // ---------------- Row 2: ন  া  র ----------------
            listOf(
                KeyItemC(
                    center = KeyC("\u09A8", size = LARGE), // ন na  (nasals + palatals)
                    top = KeyC("\u09A3"), // ণ Na
                    bottom = KeyC("\u099E"), // ঞ nya
                    left = KeyC("\u099A"), // চ cha
                    right = KeyC("\u099B"), // ছ chha
                    topLeft = KeyC("\u099C"), // জ ja
                    topRight = KeyC("\u099D"), // ঝ jha
                    bottomLeft = KeyC("!", color = MUTED),
                    bottomRight = KeyC("-", color = MUTED),
                ),
                KeyItemC(
                    center = KeyC("\u09BE", size = LARGE), // া aa-kar  (a + marks)
                    top = KeyC("\u0986"), // আ aa
                    bottom = KeyC("\u0985"), // অ a
                    left = KeyC("\u0982", color = MUTED), // ং anusvara
                    right = KeyC("\u0983", color = MUTED), // ঃ visarga
                    topLeft = KeyC("\u0981", color = MUTED), // ঁ chandrabindu
                    topRight =
                        KeyC(
                            display = KeyDisplay.IconDisplay(Icons.Outlined.ArrowDropUp),
                            action = ToggleShiftMode(true),
                            color = MUTED,
                        ),
                ),
                KeyItemC(
                    center = KeyC("\u09B0", size = LARGE), // র ra
                    top = KeyC("\u09DC"), // ড় Ra
                    bottom = KeyC("\u09DD"), // ঢ় Rha
                    left = KeyC("\u098B"), // ঋ ri
                    right = KeyC("\u09C3"), // ৃ ri-kar
                    topLeft = KeyC("(", color = MUTED),
                    topRight = KeyC(")", color = MUTED),
                    bottomLeft = KeyC(":", color = MUTED),
                    bottomRight = KeyC(";", color = MUTED),
                ),
                NUMERIC_KEY_ITEM,
            ),
            // ---------------- Row 3: ব  ি  ্ ----------------
            listOf(
                KeyItemC(
                    center = KeyC("\u09AC", size = LARGE), // ব ba  (labials)
                    top = KeyC("\u09AD"), // ভ bha
                    left = KeyC("\u09AA"), // প pa
                    right = KeyC("\u09AB"), // ফ pha
                    bottom = KeyC("\u09AE"), // ম ma
                    topLeft = KeyC("\"", color = MUTED),
                    topRight = KeyC("'", color = MUTED),
                    bottomLeft = KeyC(".", color = MUTED),
                    bottomRight = KeyC("/", color = MUTED),
                ),
                KeyItemC(
                    center = KeyC("\u09BF", size = LARGE), // ি i-kar  (i/u vowels + kars)
                    top = KeyC("\u0987"), // ই i
                    left = KeyC("\u09C0"), // ী ii-kar
                    topLeft = KeyC("\u0988"), // ঈ ii
                    bottom = KeyC("\u09C1"), // ু u-kar
                    bottomRight = KeyC("\u0989"), // উ u
                    bottomLeft = KeyC("\u09C2"), // ূ uu-kar
                    topRight = KeyC("\u098A"), // ঊ uu
                ),
                KeyItemC(
                    center = KeyC("\u09CD", size = LARGE), // ্ hasanta  (+ remaining consonants)
                    top = KeyC("\u09B2"), // ল la
                    left = KeyC("\u09B8"), // স sa
                    right = KeyC("\u09B6"), // শ sha
                    bottom = KeyC("\u09B7"), // ষ ssa
                    topLeft = KeyC("\u09B9"), // হ ha
                    topRight = KeyC("\u09AF"), // য ya
                    bottomRight = KeyC("\u09DF"), // য় ya (nukta)
                ),
                BACKSPACE_KEY_ITEM,
            ),
            listOf(
                SPACEBAR_KEY_ITEM,
                RETURN_KEY_ITEM,
            ),
        ),
    )

// Symbol layer (reached by swiping ↗ on া). Same 3x3 grid.
val KB_BN_THUMBKEY_SHIFTED =
    KeyboardC(
        listOf(
            listOf(
                KeyItemC(
                    center = KeyC("\u0964", size = LARGE), // । dari
                    top = KeyC("\u0965"), // ॥ double danda
                    left = KeyC("\u09F3"), // ৳ taka
                ),
                KeyItemC(
                    center = KeyC(",", size = LARGE),
                    top = KeyC("@"),
                    bottom = KeyC("#"),
                ),
                KeyItemC(
                    center = KeyC("?", size = LARGE),
                    top = KeyC("%"),
                    bottom = KeyC("&"),
                ),
                EMOJI_KEY_ITEM,
            ),
            listOf(
                KeyItemC(
                    center = KeyC("!", size = LARGE),
                    top = KeyC("*"),
                    bottom = KeyC("+"),
                ),
                KeyItemC(
                    center = KeyC(".", size = LARGE),
                    topRight =
                        KeyC(
                            display = KeyDisplay.IconDisplay(Icons.Outlined.ArrowDropDown),
                            action = ToggleShiftMode(false),
                            color = MUTED,
                        ),
                    left = KeyC("="),
                    right = KeyC("_"),
                ),
                KeyItemC(
                    center = KeyC("-", size = LARGE),
                    top = KeyC("~"),
                    bottom = KeyC("/"),
                ),
                NUMERIC_KEY_ITEM,
            ),
            listOf(
                KeyItemC(
                    center = KeyC("(", size = LARGE),
                    top = KeyC("["),
                    bottom = KeyC("{"),
                ),
                KeyItemC(
                    center = KeyC(")", size = LARGE),
                    top = KeyC("]"),
                    bottom = KeyC("}"),
                ),
                KeyItemC(
                    center = KeyC(":", size = LARGE),
                    top = KeyC(";"),
                    left = KeyC("\""),
                    right = KeyC("'"),
                ),
                BACKSPACE_KEY_ITEM,
            ),
            listOf(
                SPACEBAR_KEY_ITEM,
                RETURN_KEY_ITEM,
            ),
        ),
    )

val KB_BN_THUMBKEY: KeyboardDefinition =
    KeyboardDefinition(
        title = "bengali thumb-key",
        modes =
            KeyboardDefinitionModes(
                main = KB_BN_THUMBKEY_MAIN,
                shifted = KB_BN_THUMBKEY_SHIFTED,
                numeric = NUMERIC_KEYBOARD,
            ),
    )
